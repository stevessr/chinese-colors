const s="/assets/yinyang-9b10eec8.svg";export{s as Y};
