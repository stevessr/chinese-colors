import{a as e,U as t,s as n}from"./index-1543148e.js";const r=t`
0%,70%{
opacity: 0.8;
}
100%{
opacity: 0.2;
}
`,a=n.aside`
  position: fixed;
  left: 50%;
  bottom: 0.4rem;
  transform: translateX(-50%);
  animation: ${r} 60s forwards;
  .link {
    font-size: 0.5rem;
    text-decoration: none;
  }
`;function i(){return e(a,{children:e("a",{className:"link",rel:"noopener noreferrer",target:"_blank",href:"http://www.beian.miit.gov.cn/",children:"京ICP备16015459号-1"})})}export{i as default};
